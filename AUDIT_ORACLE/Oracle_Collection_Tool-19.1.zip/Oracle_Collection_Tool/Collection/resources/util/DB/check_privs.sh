#!/bin/sh
echo "testing execution privs" >check_privs.log
